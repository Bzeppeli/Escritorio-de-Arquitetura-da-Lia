package br.com.backend;

/**
 * @author zeppe
 * classe prestadores de Serviços,
 * ela crira os prestadores usados pelo escritório da lia
 * eles podem ser de diversos tipo, eletricista, construtora
 * loja de movéis projetados, etc...
 */
public class PrestadoresServicos{

    private int codigo;
    private String nome;
    private String descricaoServico;
    private double descontoOferecido;

    /**
     * Construtor da Classe, recebe os seguintes parametos
     * @param codigo - Código do Prestador de Serviços
     * @param nome - nome do Prestador de Serviços
     * @param descricaoServico - descrição do Prestador de Serviços
     * @param descontoOferecido - Desconto Oferecido pelo Prestador de Serviços
     */
    public PrestadoresServicos(int codigo, String nome, String descricaoServico, double descontoOferecido) {
        this.codigo = codigo;
        this.nome = nome;
        this.descricaoServico = descricaoServico;
        this.descontoOferecido = descontoOferecido;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricaoServico() {
        return descricaoServico;
    }

    public void setDescricaoServico(String descricaoServico) {
        this.descricaoServico = descricaoServico;
    }

    public double getDescontoOferecido() {
        return descontoOferecido;
    }

    public void setDescontoOferecido(double descontoOferecido) {
        this.descontoOferecido = descontoOferecido;
    }

    /**
     * Method para calculoDesconto, usado para determinar a quantidade de Desconto oferecido pelo
     * Prestador de Serviços
     * @param metrosQuadrados - metros quadrados do imóvel
     * @param hrsTrabalhadas - horas trabalhadas pelo prestador
     * @return desconto oferecido pelo prestador
     */
    public double calculoDesconto(double metrosQuadrados, int hrsTrabalhadas){

        double desconto = (hrsTrabalhadas/metrosQuadrados)*100;
        return this.descontoOferecido = desconto;

    }

}

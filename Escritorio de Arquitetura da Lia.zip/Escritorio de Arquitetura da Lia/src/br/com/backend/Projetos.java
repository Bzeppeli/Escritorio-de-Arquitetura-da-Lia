package br.com.backend;

import java.util.ArrayList;
import java.util.Date;

/**
 * @author zeppe
 * Class Projetos - é o coração do sistema, ela recebe todas as demais classe praticamente
 * pois sem qualquer uma delas, é quase inviavel ser concretizado um projeto
 */
public class Projetos {

    private int codigo;
    private String descricao;
    private Cliente clienteSolic;
    private Date dataInic, dataTermino;
    private double valorTotal;
    private char tipoProjeto;

    /**
     * Em projetos, você recebe Cliente que solicitou o projeto, qual funcionario está alocado,
     * data de inicio e termino, e o valor total, em termos basicos esses são os componentes mais importantes
     * dele.
     * @param codigo - codigo do projeto
     * @param descricao - descrição do projeto
     * @param clienteSolic - cliente que solicitou o projeto
     * @param dataInic - data de inicio do projeto
     * @param dataTermino - data de termino do projeto
     * @param valorTotal - valor total do projeto
     * @param tipoProjeto - Tipo de projeto (aqui deve-se atentar pois existe mais de um tipo de projeto)
     */
    public Projetos(int codigo, String descricao, Cliente clienteSolic, Date dataInic, Date dataTermino, double valorTotal, char tipoProjeto) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.clienteSolic = clienteSolic;
        this.dataInic = dataInic;
        this.dataTermino = dataTermino;
        this.valorTotal = valorTotal;
        this.tipoProjeto = tipoProjeto;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Cliente getClienteSolic() {
        return clienteSolic;
    }

    public void setClienteSolic(Cliente clienteSolic) {
        this.clienteSolic = clienteSolic;
    }

    public Date getDataInic() {
        return dataInic;
    }

    public void setDataInic(Date dataInic) {
        this.dataInic = dataInic;
    }

    public Date getDataTermino() {
        return dataTermino;
    }

    public void setDataTermino(Date dataTermino) {
        this.dataTermino = dataTermino;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public char getTipoProjeto() {
        return tipoProjeto;
    }

    public void setTipoProjeto(char tipoProjeto) {
        this.tipoProjeto = tipoProjeto;
    }


    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    @Override
    public String toString() {
        return "Projetos{" +
                "codigo=" + codigo +
                ", descricao='" + descricao + '\'' +
                ", clienteSolic=" + clienteSolic +
                ", dataInic=" + dataInic +
                ", dataTermino=" + dataTermino +
                ", valorTotal=" + valorTotal +
                ", tipoProjeto=" + tipoProjeto +
                '}';
    }

    /**
     * method MaterialUsado, serve para calcular e add
     * no preço final o preço dos materiais usados
     * no decorrer da obra.
     * @param refCatalogo - referencia do catalogo de materiais
     * @return preço final de todos os materiais, e somado ao preço final do projeto
     */
    public double materialUsado(int refCatalogo){

        double valorMaterial = 0;
        ArrayList<Materiais> materiais = new ArrayList<Materiais>();
        MateriaisMenu mm = new MateriaisMenu();

        materiais.add(mm.pesquisarMateriais(refCatalogo));
        valorMaterial = materiais.get(refCatalogo).getPreco()+ valorMaterial;
        return this.valorTotal+=valorMaterial;
    }

}

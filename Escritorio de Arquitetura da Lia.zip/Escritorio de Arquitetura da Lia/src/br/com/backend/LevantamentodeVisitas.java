package br.com.backend;

import java.util.Date;

public class LevantamentodeVisitas {
    private Cliente cliente;
    private Projetos projetos;
    private Date dataVisita;
    private char tipoVisita;

    public void cotasComodo(){
        //CadastroProjeto cp = new CadastroProjeto();


    }
}
